from flask import Flask, jsonify, request

app = Flask(_name_)

Marca = [
    {
    'id':1
    }
]

@app.route('/Marca', methods=['GET'])
def buscar():
    return jsonify(Marca)
app.route(port=10, host'https://gestaoavista.tggestaodenegocios.com.br/api/1.1/obj',debug = True)

print(id)